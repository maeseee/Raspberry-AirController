# PiOT-Relay-Board

This repository has an example Python script to drive the ModMyPi PiOT relay board. It includes examples of toggling the GPIO pins of the RPi as well as the handshaking required to start and stop the board in more advanced installations.

It also includes a dimensioned PDF and to scale DXF drawing of the PCB and main components.
